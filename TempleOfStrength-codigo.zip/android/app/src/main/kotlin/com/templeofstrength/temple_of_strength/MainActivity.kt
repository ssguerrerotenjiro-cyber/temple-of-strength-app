package com.templeofstrength.temple_of_strength

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
